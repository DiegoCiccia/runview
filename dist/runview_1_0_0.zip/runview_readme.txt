AutoIt program to view a Stata help file from an external text editor
Version: 1.0.0
Date: 16 June 2024
Authors: Diego Ciccia, cicciadiego99@gmail.com; Friedrich Huebler, fhuebler@gmail.com, www.huebler.info
Installation instructions: https://github.com/DiegoCiccia/runview, http://huebler.blogspot.com/2008/04/stata.html
